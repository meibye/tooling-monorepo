# Run Open WebUI with CUDA GPU support in Docker, exposing port 3000 and persisting data
docker run -d -p 3000:8080 --gpus all --add-host=host.docker.internal:host-gateway -v open-webui:/app/backend/data --name open-webui --restart always ghcr.io/open-webui/open-webui:cuda
