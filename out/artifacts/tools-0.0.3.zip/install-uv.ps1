# install-uv.ps1
# Installs the 'uv' Python package manager using the official installer.

irm https://astral.sh/uv/install.ps1 | iex

